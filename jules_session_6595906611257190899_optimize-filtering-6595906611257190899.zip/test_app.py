import streamlit as st

st.title("Streamlit Test")
st.write("Hello, world!")
print("--- Minimal app script executed ---")
